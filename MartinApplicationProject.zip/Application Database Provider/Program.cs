﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Application_Objects;
using Application_Database_Provider.Repository;

namespace Application_Database_Provider
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
