﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application_Objects
{
    public class FilterObject
    {
        public DateInterval newInterval { get; set; }
        public string subject { get; set; }
    }
}
